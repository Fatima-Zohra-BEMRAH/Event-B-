# HiMAD_Verification — Rodin Project (Importable)

Complete Event-B implementation of the Hi-MAD MDP reduction pipeline, ready to import into Rodin 3.x.

## Contents

| File                     | Role                                                |
| ------------------------ | --------------------------------------------------- |
| `.project`               | Eclipse/Rodin project descriptor                    |
| `C0_Agents.buc`          | Context — agent universe, scoring, thresholds       |
| `M0_FullMDP.bum`         | Abstract machine — Definition 1 (full MDP)          |
| `M1_ContextMDP.bum`      | First refinement — Definition 2 (context discovery) |
| `M2_QoSMDP.bum`          | Second refinement — Definition 3 (QoS selection)    |

## How to import

**Option A — Import the ZIP directly:**
1. Launch Rodin and open your workspace.
2. **File → Import → General → Existing Projects into Workspace → Next**.
3. Tick **Select archive file** and browse to `HiMAD_Verification.zip`.
4. The project appears with checkbox ticked → **Finish**.
5. The Event-B Explorer (left panel) now shows `HiMAD_Verification` with the four files. Expand each to see sets, variables, invariants, events.

**Option B — Import the unzipped folder:**
1. Unzip `HiMAD_Verification.zip` somewhere outside your workspace.
2. **File → Import → General → Existing Projects into Workspace → Next**.
3. Tick **Select root directory**, browse to the unzipped folder. Tick **Copy projects into workspace**.
4. **Finish**.

## After import — first checks

1. **No red error markers in the Explorer.** If you see one, double-click the file and check the Problems view (Window → Show View → General → Problems). The most common issue is a missing plug-in — make sure you have the Atelier B Provers and SMT plug-ins installed (see `HiMAD_Rodin_implementation_guide.md`).

2. **Generate proof obligations.** Right-click the project → **Build Project**. Rodin runs the static checker and proof obligation generator on all four files. Watch the bottom-right status bar.

3. **Open the Proof Obligations view.** Window → Show View → Event-B → Proof Obligations. You should see roughly 40–50 POs across the three machines.

4. **Run the auto-tactic.** Select all undischarged POs (Ctrl+A in the view), right-click → **Apply Auto/Post Tactic**. Most close immediately. The remaining 4–6 require interactive proof — the implementation guide walks through the typical cases.

## Notes on the encoding choices

- **Action parameter named `act`** (not `α`) for ASCII identifier safety. The skeleton document uses `α` for readability but Rodin's well-formed identifiers are easier to keep ASCII.
- **Scores typed as `ℕ`** (axioms `ax3`, `ax4`) because Rodin lacks native real-number support. Multiply your real-valued QoS / context scores by 1000 (or any fixed scale) before threshold comparison — this is sound for `≥` checks. State this in your paper's modeling-notes paragraph.
- **`extended="false"`** on every refining event: each refinement re-states all parameters, guards, and actions explicitly. This produces more verbose XML but makes the refinement chain self-documenting and easier to debug. If you prefer the shorter `extended="true"` form, you can edit each event in Rodin after import.
- **Witnesses on M2's `discover_context` and `revoke_context`** (`a' = a`) are required because the abstract event in M1 also has parameter `a`; the witness tells Rodin the refined parameter is the same as the abstract one. Without these, the refinement POs will fail.
- **Range subtraction `⩥`** uses Unicode `\u2A85` in the XML; Rodin's input assistant calls it `\ransub`.

## If something goes wrong

- **"Configuration is invalid" error** on opening a file: your Rodin version is older than this project's file-format version. Update Rodin to the latest 3.x.
- **POs that won't auto-discharge** even after enabling SMT: try the manual sequence `lasoo → pp` (load related hypotheses, then predicate prover). The guide explains each tactic.
- **A refinement PO of form `evt/GRD` fails**: usually means a strengthened guard in the refining event lost a hypothesis path back to the abstract guard. Add the missing premise as a guard or add a witness.

## Once everything is green

Open **Window → Show View → Event-B → Statistics** to get total/discharged/manual PO counts per machine — copy these into the table in your paper's verification section. Right-click any individual PO → **Export Proof Tree** to save proof artefacts for an appendix or reproducibility submission.
