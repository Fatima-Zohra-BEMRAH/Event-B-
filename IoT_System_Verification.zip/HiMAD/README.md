# Hi-MAD Rodin Project — v7

## What's fixed in v3

Two refinement-chain errors from v2 are resolved:

* `Abstract event Node_Register not found` (M3)
* `Abstract event Service_Remove not refined, although not disabled` (M2)

### Root cause

Every abstract event must be **explicitly carried forward** at each refinement
level — either by full refinement or by an **extended event**
(`extended="true"`).  v2 omitted these passthrough events; v3 adds them.

### Implementation

v3 introduces two helper macros:

| Macro            | What it generates                                            |
|------------------|--------------------------------------------------------------|
| `passthrough(L)` | `EVENT L EXTENDS L END` — inherits abstract event unchanged   |
| `extends(L, …)`  | Extended event that ADDS new params/guards/actions to abstract |

### M2 now contains passthrough events for all unchanged M1 events:

    Device_Register, Device_Deregister, Node_Register,
    Sensor_Attach, Actuator_Attach, Sensor_Update, Actuator_Execute,
    Node_Start_Processing, Node_Complete_Processing,
    Service_Deploy, Service_Remove,
    System_Fault, System_Recover

The three `Agent_Register_*` events use `extends(…)` to add the agent_algo,
agent_mgt, agent_supervisor, agent_perf, low_agent_node initializations.

### M3 now contains passthrough events for all unchanged M2 events:

    Device_Register, Device_Deregister,
    Sensor_Attach, Actuator_Attach, Sensor_Update, Actuator_Execute,
    Node_Start_Processing, Node_Complete_Processing,
    Service_Remove, System_Fault,
    Agent_Register_HIGH, Agent_Register_MID, Agent_Register_LOW,
    Link_Establish, Link_Remove,
    Agent_Monitor, Agent_Policy_Update, Switch_To_Execution

`Node_Register` and `Service_Deploy` are now `extends(…)` events that only
add the energy / QoS-related behavior on top of the abstract.

`Fault_Recovery_Agent` and `Fault_Recovery_Node` use `extends(…)` with
`refines="System_Recover"` — this is **event splitting**: one abstract event
refined by two concrete events, each handling a sub-case.

## How to import

1. Open Rodin (≥ 3.5) with the ProB plug-in installed.
2. Delete the previous `HiMAD` project (if any).
3. **File → Import → General → Existing Projects into Workspace**.
4. Select **Select archive file** → choose `HiMAD_Rodin_Project_v7.zip`.
5. Tick `HiMAD` → **Finish**.

Once imported, all the red error markers should be gone.  POs will be
generated automatically; auto-provers handle the trivial ones, the rest are
documented in `HiMAD_EventB_Formal_Model.md` §8.

## Files

    HiMAD/
    ├── .project        Eclipse/Rodin project descriptor
    ├── C0.buc          ENTITY carrier + entity-class constants
    ├── C1.buc          QoS, DRL, mgt, thresholds (extends C0)
    ├── M0.bum          Abstract IoT system
    ├── M1.bum          Physical + Edge-Fog (refines M0)
    ├── M2.bum          Network + Platform   (refines M1) — v3 passthrough events added
    └── M3.bum          Application + QoS    (refines M2) — v3 passthrough + extends events added
