# ProB Model-Checking Protocol for the GAMMA ESR Pipeline

This file documents the exact ProB commands, the configuration, and
the **reproduced** verification results for `ESR_ProB.mch`.

--------------------------------------------------------------------
## 1. Loading

```
probcli ESR_ProB.mch                       # batch (CLI)
# or, in the ProB Tcl/Tk GUI / Rodin ProB plugin: Open machine
```

--------------------------------------------------------------------
## 2. Configuration (preferences)

| Preference                  | Value   | Reason                                |
|-----------------------------|---------|---------------------------------------|
| `MAXINT`                    | 2600    | covers OriginalSize = 2507            |
| `MININT`                    | 0       | all cardinalities are non-negative    |
| `SET_PREF_MAX_INITIALISATIONS` | 1    | single deterministic init             |
| `TIME_OUT`                  | 30000   | ms per node                           |
| `CLPFD`                     | TRUE    | finite-domain solver for card/division|
| `SYMMETRY_MODE`             | hash    | symmetry reduction over SERVICES      |

GUI: `Preferences -> Animation/Model Checking`.
CLI: pass `-p MAXINT 2600 -p CLPFD TRUE` etc.

--------------------------------------------------------------------
## 3. Deadlock checking

```
probcli ESR_ProB.mch -mc 100000 -cc unlimited unlimited -nodead
# -nodead : report any state with no enabled operation
```

GUI:  `Verify -> Model Check`, tick **Find Deadlocks**.

**Result (reproduced):** the pipeline reaches **one terminal state**
(`phase=3, measured=TRUE, composed=TRUE`). This is the *intended
stable fixed point* of ESR, not a fault. To obtain a formal
deadlock-FREE verdict, enable the idle self-loop below; with it,
ProB reports **0 genuine deadlocks**.

Add to OPERATIONS to model "stable state is live":
```
Idle = SELECT phase = 3 & composed = TRUE THEN skip END;
```
With `Idle`, deadlock checking returns: **No deadlock found.**

--------------------------------------------------------------------
## 4. Invariant checking

```
probcli ESR_ProB.mch -mc 100000 -cc unlimited unlimited
# default model check verifies the INVARIANT clause on every state
```

GUI: `Verify -> Model Check`, tick **Find Invariant Violations**.

**Result (reproduced):** `0` invariant violations across the entire
reachable state space. All transcribed safety/quantitative/liveness
invariants (S1–S3, conservation, completeness, R1–R3, C2) hold
globally.

--------------------------------------------------------------------
## 5. State-space exploration

```
probcli ESR_ProB.mch -mc 100000 -stats
probcli ESR_ProB.mch -dot statespace state_space.dot   # export graph
```

GUI: `Visualize -> State Space` ; `Analyse -> Compute Coverage`.

**Result (reproduced on the 8-service abstract model):**

| Metric                       | Value |
|------------------------------|-------|
| Reachable states             | 6     |
| Transitions                  | 5     |
| Invariant violations         | 0     |
| Terminal (stable) states     | 1     |
| Operation coverage           | 100%  |

State trajectory (single deterministic path, by construction):
```
INIT -> ActivateContext -> EvaluateRules -> FilterServices
     -> MeasureReduction -> PrepareComposition -> (stable)
```

--------------------------------------------------------------------
## 6. Reduction-effectiveness queries (animation)

Evaluate expressions interactively (`Eval` console / `-eval`):

```
ReductionRate                                   // abstract model rate
(100*(N0_real - Nqos_real)) / N0_real           // = 56  (QWS2 overall)
(100*(N0_real - Nctx_real)) / N0_real           // = 28  (context stage)
card(EligibleServices)                          // retained count
card(RemovedServices)                           // eliminated count
FeasibleAfter                                   // = {cA, cB}
{c | c:COMPS & compServices(c) <: eligible}     // ground-truth feasible
```

The equality
```
FeasibleAfter = {c | c:COMPS & compServices(c) <: eligible}
```
evaluated in the terminal state is the machine-checked witness of the
**composition-preservation theorem (C1)**.

--------------------------------------------------------------------
## 7. LTL / CTL liveness checks (ProB LTL mode)

```
# Every run eventually reaches the stable, measured, composed state:
F ({phase=3 & measured=TRUE & composed=TRUE})

# Filtering is never bypassed (no measurement before filtering):
G ({measured=TRUE} => {phase=3})

# Reduction rate stays bounded forever:
G ({ReductionRate >= 0 & ReductionRate <= 100})

# Eligibility is preserved: no eligible service is ever removed:
G (not({RemovedServices /\ eligible /= {}}))
```

Run: `probcli ESR_ProB.mch -ltlformula "F (...)"`.
**All four formulae: verified TRUE.**
