# ESR · ProB2-UI Visualization (VisB)

This is the **native ProB2-UI** visualization for the ESR pipeline. It is a
VisB pair — an SVG image plus a JSON glue file that binds SVG elements to the
state of `ESR_ProB.mch` and turns five rectangles into clickable operation
buttons. (This is the ProB2-UI format; it is *not* the same as the BMotionWeb
`esr_visualization.json` / `esr_bmotion.js`, which target Rodin.)

## Files
- `esr_visb.svg`  — the dashboard image (service graph + 5 dashboards + buttons).
- `esr_visb.json` — the glue: `items` (attribute bindings) and `events`
  (button → operation). It references `esr_visb.svg`, so keep them in the
  **same folder** as `ESR_ProB.mch` (or beside each other).

## Steps in ProB2-UI

1. **Fichier → Ouvrir un fichier machine** → open `ESR_ProB.mch`
   (put `esr_visb.svg` and `esr_visb.json` in the same folder first).
2. Open the visualization: **Visualisation → Open VisB File** (menu may read
   *Visualisation → Ouvrir un fichier VisB* / *VisB Visualisation*), then select
   `esr_visb.json`. The dashboard appears in the **Visualisation** panel
   (bottom-center; expand it / pop it out to a window).
3. Animate either way — both update the dashboard live:
   - **Click the buttons inside the visualization** (ActivateContext →
     EvaluateRules → FilterServices → MeasureReduction → PrepareComposition), or
   - double-click the same operations in the **Opérations** panel.
4. Watch the widgets change:
   - service nodes turn **green** (eligible) / **red** (removed) after
     FilterServices;
   - Dashboard 3 shows retained / eliminated counts;
   - Dashboard 4 fills the bar to **56 %** after MeasureReduction;
   - Dashboard 5 shows invariants-hold (green), the model ReductionRate,
     `FeasibleAfter`, and flips to **stable (terminated)** after
     PrepareComposition.

Use the **Histoire** back-arrows (or ↺ reset) to replay from the start.

## What each binding shows
- `phase_label`, `d5_composed`, `d5_measured` — control state.
- `node_s1..s8` `fill` — per-service status (eligible/removed/neutral).
- `d2_ctx_led`, `d2_match` — context activation + matching count.
- `d3_keep`, `d3_drop` — `card(EligibleServices)` / `card(RemovedServices)`.
- `d4_orig/d4_reduced/d4_rate/d4_bar` — QWS2 scaled reduction (2507→1085, 56 %).
- `d5_inv*` — the conjunction of the safety invariants (green = all hold).
- `d5_dead*` — terminal/stable indicator.
- `d5_feasible` — `FeasibleAfter` set (becomes `{cA,cB}`; `cC` excluded, since
  it needs the non-eligible service s3).

## Notes / troubleshooting
- VisB `value` expressions must yield **strings**, which is why numbers are
  wrapped in `TO_STRING(...)` and pieces joined with `^`. If your ProB build
  uses a different attribute-value convention and a text item shows blank, open
  **Visualisation → (Edit/Reload)** and re-load the JSON after editing.
- If clicking a button does nothing, that operation isn't enabled in the
  current state (guards) — follow the pipeline order above.
- If the SVG doesn't appear, confirm `"svg": "esr_visb.svg"` resolves relative
  to the JSON's location (keep both files together).
- The terminal state (all operations disabled) is the **designed** end of the
  pipeline, not a fault; ProB labels it a deadlock — see `ProB_commands.md`
  for the optional `Idle` self-loop if you want a clean no-deadlock verdict.
